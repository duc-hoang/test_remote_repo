var ToDoView = Backbone.View.extend({
	tagName:'li',
	toDoTpl:_.template(jQuery('#item-template').html()),
	events:{
		'dblclick label':'edit',
		'keypress .edit':'updateOnEnter',
		'blur .edit':'close'
	},
	initialize: function(){
		this.el = jQuery('#todo');
	},
	render: function(){
		this.el.html(this.toDoTpl(this.model.toJSON()));
		this.input = this.jQuery('.edit');
		return this;
		
	},
	edit: function(){
		
	},
	close: function(){
		
	},
	updateOnEnter: function(e){
		
	}
});

var toDoView = new ToDoView({model: myToDo});

var ToDosView = Backbone.View.extend({
	tagName:"ul",
	className:"container",
	id:"todos"
});

var toDosView = new ToDosView();
console.log(toDosView.el);